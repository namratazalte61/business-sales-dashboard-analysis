# Business Sales Performance Analysis & Decision Dashboard

## 📌 Project Overview
This project analyzes sales data using Excel and Power BI to generate insights and support business decisions.

## 🛠 Tools Used
- Microsoft Excel
- Power BI

## 📊 Features
- Data Cleaning
- Pivot Tables
- Interactive Dashboard
- Business Insights

## 📁 Project Structure
- data/ → Sample dataset
- excel/ → Excel analysis
- powerbi/ → Dashboard file
- report/ → Final PDF report

## 🚀 Outcome
Transform raw data into actionable business insights.
